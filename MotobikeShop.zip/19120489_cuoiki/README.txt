Lop:19-3
MSSV:19120489
Ten: Luu Truong Duong
email: luutruongduong20@gmail.com

link demo:
https://youtu.be/Fe9v238xIKM

link du phong:
https://youtu.be/YgrlrLbFqBw

-Chuc nang:
1.Quan ly danh muc:
-Xem danh sach hang xe, them, xoa ten hang xe
-Danh sach san pham ung voi moi hang, them, xoa, sua thong tin mot xe may
2.Quan ly don hang
-Danh sach cac don hang trong thang, xem chi tiet don hang, cap nhat chi tiet don hang,xoa don hang
3.Thong ke bao cao
-Hien thi danh sach mat hang sap het
-Cac mat hang ban chay trong tung thang
-Doanh thu tung thang va tong the.

-Lam them:
-Thao tac cac mat hang trong kho
