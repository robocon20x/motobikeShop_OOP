#pragma once
#include<string>
#include<iostream>
#include<sstream>
#include<vector>
#include <stdio.h>
#include <conio.h>
#include<memory>
#include<fstream>
#include "Tokenizer.h"
#include "Company.h"
#include "Model.h"
#include "Motorbike.h"

using namespace std;

class CompanyFactory {
private:
	inline static CompanyFactory* _instance = NULL;
	vector<Company> _prototypes;
	CompanyFactory();
public:
	int total();
	static CompanyFactory* instance();
	Company creatCompany(string);
	
	int findCompany(string);
	int findModel(string, Model);
	int findModel(string, string);

	void listCompany();
	void listModel(string);
	void listAll();
	
	void addCompany(string);
	void addCompany(string, vector<Model>);
	void addModel(string, Model);
	
	void setCompany(string, string);
	void setModel(string, Model, Model);

	void deleteCompany(string);
	void deleteModel(string, Model);

	void update();

};