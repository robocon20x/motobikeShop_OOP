#include"Receipt.h"

Receipt::Receipt() = default;

Receipt::Receipt(string code, Customer customer, Time time, vector<pair<Motorbike, int>> items) {
	_code = code;
	_customer = customer;
	_time = time;
	_items = items;
}

string Receipt::getCode() {
	return _code;
}
void Receipt::setCode(string code) {
	_code = code;
}

Customer Receipt::getCustomer() {
	return _customer;
}
void Receipt::setCustomer(Customer customer) {
	_customer = customer;
}

Time Receipt::getTime() {
	return _time;
}
void Receipt::setTime(Time time) {
	_time = time;
}

vector<pair<Motorbike, int>> Receipt::getItems() {
	return _items;
}
void Receipt::setItems(vector<pair<Motorbike, int>> items) {
	_items = items;
}

double Receipt::totalPrice() {
	double result = 0;
	for (int i = 0; i < _items.size(); i++) {
		result += (stof(_items[i].first.getSellPrice()) * _items[i].second);
	}
	return result;
}

void Receipt::listBestSell(vector<Receipt> list) {
	map<string, int> Map;

	for (int i = 0; i < list.size(); i++) {
		vector<pair<Motorbike, int>> items = list[i].getItems();
		for (int j = 0; j < items.size(); j++) {
			string name = items[j].first.getCompany() + " " + items[j].first.getModel().getModelName();
			int number = items[j].second;
			if (Map.find(name) == Map.end()) {
				Map.insert(pair<string, int>(name, number));
			}
			else Map[name] += number;
		}
	}

	vector<pair<string, int> > List;

	for (auto& x : Map) {
		List.push_back(x);
	}

	// Sort
	for (int i = 0; i < List.size() - 1; i++)
	{
		int max = i;
		for (int j = i + 1; j < List.size(); j++)
		{
			if (List[max].second < List[j].second)
				max = j;
		}
		if (max != i)
		{
			string first = List[i].first;
			int second = List[i].second;
			List[i].first = List[max].first;
			List[i].second = List[max].second;
			List[max].first = first;
			List[max].second = second;
		}
	}

	int count = 0;
	cout << "Hang ------- Dong san pham ---------------- So luong da ban" << endl;
	for (auto& x : List) {
		if (count >= 10)
			break;
		cout << x.first << " x " << x.second << endl;

		count++;
	}
}

Receipt Receipt::parse(vector<string> buffer) {
	string code = buffer[0];
	Customer customer = Customer::parse(buffer[1]);
	Time time = Time::parse(buffer[2]);
	int number = stoi(buffer[3]);
	vector<pair<Motorbike, int>> products;
	for (int i = 4; i < number + 4; i++)
	{
		vector<string>tokens = Tokenizor::split(buffer[i], "#");
		vector<string>motorbikeModel = Tokenizor::split(tokens[0], " ");
		string company = motorbikeModel[0];
		Model model = Model::parse(motorbikeModel[1], "|");
		Motorbike motorbike = MotorbikeFactory::instance()->createMotorbike(company, model);
		int quantity = stoi(tokens[1]);
		products.push_back(pair<Motorbike, int>(motorbike, quantity));
	}
	Receipt result(code, customer, time, products);
	return result;
}

string Receipt::toString() {
	stringstream writer;
	writer << "*** Don hang " << _code << " :" << endl;
	writer << "- Khach hang: " << endl;
	writer << _customer << endl;
	writer << "- Ngay mua hang: " << _time << endl;
	writer << "- Danh sach san pham: " << endl;
	for (int i = 0; i < _items.size(); i++)
	{
		writer << " " << i + 1 << ". " << setw(6) << left << _items[i].first.getCompany() << " ";
		writer << setw(20) << left << _items[i].first.getModel().getName();
		writer << setw(20) << left << _items[i].first.getModel().getVersion() << ": ";
		writer << setw(10) << left << _items[i].first.getSellPrice();
		writer << "x " << _items[i].second << endl;
	}
	writer << "--> Tong thanh toan: " << to_string(totalPrice()) << endl;
	return writer.str();
}

string Receipt::writetofile()
{
	stringstream builder;
	builder << _code << endl;
	builder << _customer.toString() << endl;
	builder << _time << endl;
	builder << _items.size() << endl;
	for (int i = 0; i < _items.size(); i++)
	{
		builder << _items[i].first.getCompany() << " " << _items[i].first.getModel().toString();
		builder << "#" << _items[i].second << endl;
	}
	return builder.str();
}