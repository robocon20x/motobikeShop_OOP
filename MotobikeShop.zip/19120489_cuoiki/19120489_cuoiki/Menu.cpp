#include"Menu.h"

void Menu::MenuList() {
	cout << "1. Quan ly danh muc " << endl;
	cout << "2. Quan ly don hang" << endl;
	cout << "3. Thong ke bao cao " << endl;
	cout << "4. Thoat" << endl;
	cout << "Lua chon: ";
}
void Menu::selectChoice(int choice) {
	switch (choice) {
	case 1: {
		int choice1;
		do {
			MenuCompany::MenuList();			
			cin >> choice1;
			MenuCompany::selectChoice(choice1);
		} while (choice1 != 10);
		break;
	}
	case 2: {
		int choice2;
		do {
			MenuReceipt::MenuList();
			cin >> choice2;
			MenuReceipt::selectChoice(choice2);
		} while (choice2 != 5);
		break;
	}
	case 3: {
		int choice3;
		do {
			MenuReport::MenuList();
			cin >> choice3;
			MenuReport::selectChoice(choice3);
		} while (choice3 != 10);
		break;
	}
	case 4: {
		system("cls");
		break;
	}

	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choice;
	}
	}
}