#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include<vector>
#include"Tokenizer.h"
using namespace std;

class Customer {
private:
	string _name;
	string _phonenumber;
	string _email;
	string _address;
public:
	Customer();
	Customer(string, string, string, string);

	string getName();
	void setName(string);

	string getPhone();
	void setPhone(string);
	
	string getEmail();
	void setEmail(string);

	string getAddress();
	void setAddress(string);

	string toString();
	static Customer parse(string);

	friend ostream& operator<<(ostream& o, const Customer& s);
};