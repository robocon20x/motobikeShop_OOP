#pragma once
#include "Customer.h"
#include "Motorbike.h"
#include "Time.h"
#include "MotorbikeFactory.h"
#include <map>

class Receipt {
private:
	string _code;
	Customer _customer;
	Time _time;
	vector<pair<Motorbike, int>> _items;
public:
	Receipt();
	Receipt(string, Customer, Time, vector<pair<Motorbike, int>>);
	
	string getCode();
	void setCode(string);

	Customer getCustomer();
	void setCustomer(Customer);

	Time getTime();
	void setTime(Time);

	vector<pair<Motorbike, int>> getItems();
	void setItems(vector<pair<Motorbike, int>> items);

	double totalPrice();
	static void listBestSell(vector<Receipt>);

	string toString();
	static Receipt parse(vector<string>);
	string writetofile();
};