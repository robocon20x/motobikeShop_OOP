#include "MotorbikeFactory.h"

//MotorbikeFactory* MotorbikeFactory::_instance = NULL;

MotorbikeFactory* MotorbikeFactory::instance()
{
    if (_instance == NULL)
    {
        _instance = new MotorbikeFactory();
    }
    return _instance;
}

int MotorbikeFactory::total()
{
    return _prototypes.size();
}

MotorbikeFactory::MotorbikeFactory()
{
    ifstream filein("Inventory.txt");
    string buffer;
    int size;

    filein >> size;
    filein.ignore();
    for (int i = 0; i < size; i++)
    {
        getline(filein, buffer);
        Motorbike temp = Motorbike::parse(buffer);
        _prototypes.push_back(temp);
    }
    filein.close();
}

void MotorbikeFactory::update()
{
    ofstream fileout("Inventory.txt");
    fileout << _prototypes.size() << endl;
    for (int i = 0; i < _prototypes.size(); i++)
    {
        fileout << _prototypes[i].toString() << endl;
    }
    fileout.close();
}

Motorbike MotorbikeFactory::motorbikeModel(int before)
{
    return _prototypes[before];
}

Motorbike MotorbikeFactory::createMotorbike(string company, Model model)
{
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == company)
        {
            if ((_prototypes[i].getModel().getName() == model.getName()) &&
                (_prototypes[i].getModel().getVersion() == model.getVersion()))
            {
                return _prototypes[i];
            }
        }
    }
}

bool MotorbikeFactory::isExists(string company)
{
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == company)
            return true;
    }
    return false;
}

bool MotorbikeFactory::isExists(string company, Model model)
{
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == company)
        {
            if ((_prototypes[i].getModel().getName() == model.getName()) &&
                (_prototypes[i].getModel().getVersion() == model.getVersion()))
                return true;
        }
    }
    return false;
}

void MotorbikeFactory::addModel(string company, Model model)
{
    if (isExists(company, model))
        return;

    Motorbike temp(company, model, "0", "0", 0);
    _prototypes.push_back(temp);
    update();
}


void MotorbikeFactory::setCompany(string before, string after)
{
    if (!isExists(before))
        return;

    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == before)
        {
            _prototypes[i].setCompany(after);
        }
    }
    update();
}

void MotorbikeFactory::setModel(string company, Model before, Model after)
{
    if (!isExists(company, before))
        return;

    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == company)
        {
            if ((_prototypes[i].getModel().getName() == before.getName()) &&
                (_prototypes[i].getModel().getVersion() == before.getVersion()))
            {
                _prototypes[i].setModel(after);
                break;
            }
        }
    }
    update();
}

void MotorbikeFactory::deleteCompany(string company)
{
    if (!isExists(company))
        return;

    for (int i = _prototypes.size() - 1; i >= 0; i--)
    {
        if (_prototypes[i].getCompany() == company)
        {
            _prototypes.erase(_prototypes.begin() + i);
        }
    }
    update();
}

void MotorbikeFactory::deleteModel(string company, Model model)
{
    if (!isExists(company, model))
        return;

    for (int i = _prototypes.size() - 1; i >= 0; i--)
    {
        if (_prototypes[i].getCompany() == company)
        {
            if ((_prototypes[i].getModel().getName() == model.getName()) &&
                (_prototypes[i].getModel().getVersion() == model.getVersion()))
            {
                _prototypes.erase(_prototypes.begin() + i);
                break;
            }
        }
    }
    update();
}

void MotorbikeFactory::listPrice()
{
    cout << "Hang ------- Dong san pham ------------ Gia von(VND) ----------- Gia ban(VND)" << endl;
    for (int i = 0; i < _prototypes.size(); i++)
    {
        cout << setw(6) << left << _prototypes[i].getCompany() << " ";
        cout << setw(17) << left << _prototypes[i].getModel().getName();
        cout << setw(17) << left << _prototypes[i].getModel().getVersion() << " ";
        cout << setw(25) << left << _prototypes[i].getCostPrice();
        cout << setw(38) << left << _prototypes[i].getSellPrice() << endl;
    }

    cout << endl;
 /*   int choose = 0;
    cout << "Tuy chon:" << endl;
    cout << "1.Quay lai menu" << endl;
    cout << "Nhap lua chon: ";
    cin >> choose;
    switch (choose) {
    case 1: {
        return;
    }
    default: {
        cout << "nhap sai lua chon" << endl;
        cout << "nhap lai lua chon: ";
        cin >> choose;
    }

    }

    system("cls");*/
}

void MotorbikeFactory::setPrice(string company, Model model, string costPrice, string sellPrice)
{
    if (!isExists(company, model))
    {
        cout << "Dong Motorbike " << company << " " << model << " khong ton tai !";
        return;
    }
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == company)
        {
            if ((_prototypes[i].getModel().getName() == model.getName()) &&
                (_prototypes[i].getModel().getVersion() == model.getVersion()))
            {
                _prototypes[i].setCostPrice(costPrice);
                _prototypes[i].setSellPrice(sellPrice);
                break;
            }
        }
    }
    update();
}

void MotorbikeFactory::inventory()
{
    cout << "Hang ------- Dong san pham ---------------- So luong ton kho" << endl;
    for (int i = 0; i < _prototypes.size(); i++)
    {
        cout << setw(6) << left << _prototypes[i].getCompany() << " ";
        cout << setw(17) << left << _prototypes[i].getModel().getName();
        cout << setw(17) << left << _prototypes[i].getModel().getVersion();
        cout << setw(12) << right << _prototypes[i].getQuantity() << endl;
    }

    cout << endl;
 /*   int choose = 0;
    cout << "Tuy chon:" << endl;
    cout << "1.Quay lai menu" << endl;
    cout << "Nhap lua chon: ";
    cin >> choose;
    switch (choose) {
    case 1: {
        return;
    }
    default: {
        cout << "nhap sai lua chon" << endl;
        cout << "nhap lai lua chon: ";
        cin >> choose;
    }

    }

    system("cls");*/
}

void MotorbikeFactory::editInventory(string company, Model model, int number)
{
    if (!isExists(company, model))
    {
        cout << "Dong Motorbike " << company << " " << model << " khong ton tai !";
        return;
    }
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getCompany() == company)
        {
            if ((_prototypes[i].getModel().getName() == model.getName()) &&
                (_prototypes[i].getModel().getVersion() == model.getVersion()))
            {
                _prototypes[i].setQuantity(number);
                break;
            }
        }
    }
    update();
}

void MotorbikeFactory::AbouttoRunOutProduct()
{
    cout << "Hang ------- Dong san pham ---------------- So luong ton kho" << endl;
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (_prototypes[i].getQuantity() < 10)
        {
            cout << setw(6) << left << _prototypes[i].getCompany() << " ";
            cout << setw(17) << left << _prototypes[i].getModel().getName();
            cout << setw(17) << left << _prototypes[i].getModel().getVersion();
            cout << setw(12) << right << _prototypes[i].getQuantity() << endl;
        }
    }

    cout << endl;
   /* int choose = 0;
    cout << "Tuy chon:" << endl;
    cout << "1.Quay lai menu" << endl;
    cout << "Nhap lua chon: ";
    cin >> choose;
    switch (choose) {
    case 1: {
        return;
    }
    default: {
        cout << "nhap sai lua chon" << endl;
        cout << "nhap lai lua chon: ";
        cin >> choose;
    }

    }

    system("cls");*/
}