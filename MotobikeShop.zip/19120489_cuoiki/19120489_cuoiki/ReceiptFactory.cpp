#include"ReceiptFactory.h"

ReceiptFactory::ReceiptFactory() {

	ifstream reader("Receipt.txt");
	int size;
	reader >> size;
	reader.ignore();
	for (int i = 0; i < size; i++)
	{
		vector<string> receipt;
		string temp;
		getline(reader, temp);
		do
		{
			receipt.push_back(temp);
			getline(reader, temp);
		} while (temp != ".");
		Receipt r = Receipt::parse(receipt);
		_prototypes.push_back(r);
	}
	reader.close();
}

ReceiptFactory* ReceiptFactory::instance() {
	if (_instance == NULL) {
		_instance = new ReceiptFactory();
	}
	return _instance;
}

int  ReceiptFactory::total() {
	return _prototypes.size();
}

int  ReceiptFactory::findReceipt(string code) {
	for (int i = 0; i < _prototypes.size(); i++) {
		if (_prototypes[i].getCode() == code)
			return i;
	}
	return -1;
}

Receipt  ReceiptFactory::getReceipt(string code) {
	for (int i = 0; i < _prototypes.size(); i++) {
		if (_prototypes[i].getCode() == code)
			return _prototypes[i];
	}
}


void ReceiptFactory::deleteReceipt(string code) {
	int pos = findReceipt(code);
	if (pos == -1)
	{
		cout << "don hang " << code << " khong ton tai" << endl;
		return;
	}
	_prototypes.erase(_prototypes.begin() + pos);
	update();
}

void ReceiptFactory::setCustomerName(Receipt& receipt, string fullname) {

	Customer customer = receipt.getCustomer();
	customer.setName(fullname);
	receipt.setCustomer(customer);
	_prototypes[findReceipt(receipt.getCode())].setCustomer(customer);
	update();
}

void ReceiptFactory::setCustomerAddress(Receipt& receipt, string address) {
	Customer customer = receipt.getCustomer();
	customer.setAddress(address);
	receipt.setCustomer(customer);
	_prototypes[findReceipt(receipt.getCode())].setCustomer(customer);
	update();
}

void ReceiptFactory::setCustomerPhone(Receipt& receipt, string phone) {
	Customer customer = receipt.getCustomer();
	customer.setPhone(phone);
	receipt.setCustomer(customer);
	_prototypes[findReceipt(receipt.getCode())].setCustomer(customer);
	update();
}

void ReceiptFactory::setCustomerEmail(Receipt& receipt, string email) {
	Customer customer = receipt.getCustomer();
	customer.setEmail(email);
	receipt.setCustomer(customer);
	_prototypes[findReceipt(receipt.getCode())].setCustomer(customer);
	update();
}

void ReceiptFactory::setTime(Receipt& receipt, string time) {
	Time datetime = Time::parse(time);
	receipt.setTime(datetime);
	_prototypes[findReceipt(receipt.getCode())].setTime(datetime);
	update();
}

void ReceiptFactory::editItem(Receipt& receipt, int pos, string motorbike, int number) {
	vector<pair<Motorbike, int>> items = receipt.getItems();

	vector<string>tokens = Tokenizor::split(motorbike, " ");

	Motorbike motor = MotorbikeFactory::instance()->createMotorbike(tokens[0], Model(tokens[1], tokens[2]));
	items[pos].first = motor;
	items[pos].second = number;
	receipt.setItems(items);
	_prototypes[findReceipt(receipt.getCode())].setItems(items);
	update();
}


void ReceiptFactory::listAll() {
	int pages = (_prototypes.size() % 2 == 0) ? (_prototypes.size() / 2) : (_prototypes.size() / 2 + 1);
	int currentpage = 1;

	while (true)
	{
		int count = 0;
		int choose = 0;
		while (count < 2)
		{
			cout << _prototypes[2 * (currentpage - 1) + count].toString() << endl;
			if (2 * (currentpage - 1) + count == _prototypes.size() - 1)
				break;
			count++;
		}
		cout << "-----------------------------------  Trang " << currentpage<<"/"<<pages;
		cout << " -----------------------------------";

		cout << "Tuy chon" << endl;
		cout << "1. Trang tiep theo" << endl;
		cout << "2. Trang truoc do" << endl;
		cout << "3. Nhap trang can xem" << endl;
		cout << "4. Tro ve menu" << endl;
		cout << "Lua chon cua ban la: ";
		cin >> choose;

		switch (choose) {
		case 1: {
			if (currentpage != pages)	currentpage++;
			break;
		}
		case 2: {
			if (currentpage != 1)	currentpage--;
			break;
		}
		case 3: {
			int number = 1;
			do {
				cout << "--Nhap trang ban can xem: ";
				cin >> number;
			} while (number<1 || number > pages);

			currentpage = number;
			break;
		}
		case 4: { 
			return;
		}
		default: {
			cout << "nhap sai lua chon" << endl;
			cout << "nhap lai lua chon: ";
			cin >> choose;
		}

		}
		system("cls");
	}
}

void ReceiptFactory::listReceiptofMonth(int month) {
	vector<Receipt> list;
	for (auto& x : _prototypes) {
		if (x.getTime().getMonth() == month) {
			list.push_back(x);
		}
	}
	int pages = (list.size() % 2 == 0) ? (list.size() / 2) : (list.size() / 2 + 1);
	int currentpage = 1;

	while (true) {
		int count = 0;
		int choose = false;
		while (count < 2) {

			cout << list[2 * (currentpage - 1) + count].toString() << endl;
			if (2 * (currentpage - 1) + count == list.size() - 1)
				break;
			count++;
		}
		cout << "-----------------------------  Trang " << currentpage << "/" << pages;
		cout << "  --------------------------------" << endl;

		cout << "Tuy chon" << endl;
		cout << "1. Trang tiep theo" << endl;
		cout << "2. Trang truoc do" << endl;
		cout << "3. Nhap trang can xem" << endl;
		cout << "4. Tro ve menu" << endl;
		cout << "Lua chon cua ban la: ";
		cin >> choose;

		switch (choose) {
		case 1: {
			if (currentpage != pages)	currentpage++;
			break;
		}
		case 2: {
			if (currentpage != 1)	currentpage--;
			break;
		}
		case 3: {
			int number;
			cout << "Nhap trang ban can xem: ";
			cin >> number;
			while (number<1 || number > pages) {
				cout << "--Nhap trang ban can xem: ";
				cin >> number;
			}

			currentpage = number;
			break;
		}
		case 4: {
			return;
		}
		default: {
			cout << "nhap sai lua chon" << endl;
			cout << "nhap lai lua chon: ";
			cin >> choose;
		}

		}
		system("cls");
	}
}

void ReceiptFactory::listBestSellofMonth(int month) {
	vector<Receipt> list;
	for (auto& x : _prototypes) {
		if (x.getTime().getMonth() == month)
		{
			list.push_back(x);
		}
	}

	Receipt::listBestSell(list);
	cout << endl;

}

void ReceiptFactory::listBestSell() {
	Receipt::listBestSell(_prototypes);
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void ReceiptFactory::incomeOfMonth(int month) {
	double income = 0, profit = 0;

	for (auto& x : _prototypes)	{
		if (x.getTime().getMonth() == month) {
			vector<pair<Motorbike, int>> z = x.getItems();
			for (auto& y : z){
				double costprice = stof(y.first.getCostPrice());
				double sellprice = stof(y.first.getSellPrice());
				income += (y.second * sellprice);
				profit += (y.second * (sellprice - costprice));
			}
		}
	}

	cout << "Doanh thu thang " << month << " : " << to_string(income) << endl;
	cout << "Loi nhuan thang " << month << " : " << to_string(profit) << endl;

	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void ReceiptFactory::income() {
	double income = 0, profit = 0;

	for (auto& x : _prototypes)	{
		vector<pair<Motorbike, int>> z = x.getItems();
		for (auto& y : z)
		{
			double costprice = stof(y.first.getCostPrice());
			double sellprice = stof(y.first.getSellPrice());
			income += (y.second * sellprice);
			profit += (y.second * (sellprice - costprice));
		}
	}

	cout << "Doanh thu toi thoi diem hien tai: " << to_string(income) << endl;
	cout << "Loi nhuan toi thoi diem hien tai: " << to_string(profit) << endl;

	cout << endl;
	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}
	}

	system("cls");
}

void ReceiptFactory::update() {
	ofstream writer("Receipt.txt");
	writer << _prototypes.size() << endl;
	for (int i = 0; i < _prototypes.size(); i++)
	{
		writer << _prototypes[i].writetofile();
		writer << "." << endl;
	}
}