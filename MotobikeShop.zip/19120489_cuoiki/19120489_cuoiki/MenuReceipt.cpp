#include"MenuReceipt.h"

void MenuReceipt::MenuList() {
	system("cls");
	cout << "1. Danh sach cac don hang trong mot thang" << endl;
	cout << "2. Danh sach hoa don trong nam" << endl;
	cout << "3. Sua thong tin hoa don" << endl;
	cout << "4. Xoa hoa don" << endl;
	cout << "5. Quay lai" << endl;
	cout << "Lua chon: ";
}

void MenuReceipt::selectChoice(int choice) {
	switch (choice) {
	case 1: {
		listReceiptofMonth();
		break;
	}
	case 2: {
		listReceiptAll();
		break;
	}
	case 3: {
		setReceipt();
		break;
	}
	case 4: {
		deleteReceipt();
		break;
	}
	case 5: {
		system("cls");
		break;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choice;
	}
	}
}

void MenuReceipt::listReceiptofMonth() {
	system("cls");
	int month;
	int thisMonth = Time::currentMonth();
	cout << "Thang hien tai la: " << thisMonth << endl;
	cout << "Nhap thang ban muon xem" << endl;
	cin >> month;
	while (month > thisMonth || month < 1)
	{
		cout << "Thang ban nhap khong hop le" << endl;
		cin >> month;
	}
	cin.ignore();
	cout << "Danh sach hoa don thang " << month << " :" << endl;
	ReceiptFactory::instance()->listReceiptofMonth(month);
}

void MenuReceipt::listReceiptAll() {
	system("cls");
	cout << "Danh sach cac hoa don :" << endl;
	ReceiptFactory::instance()->listAll();
}

void MenuReceipt::setReceipt() { 
	int choose;
	do {
		system("cls");
		MenuEditReceipt::MenuList();
		cin >> choose;
		MenuEditReceipt::selectChoice(choose);
	} while (choose != 7);

}

void MenuReceipt::deleteReceipt() {
	system("cls");
	string code;
	int flag1 = 1;
	system("cls");
	cout << "Nhap ma don hang cua don hang ban muon xoa " << endl;
	cin >> code;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	ReceiptFactory::instance()->deleteReceipt(code);
	cout << "Danh sach cac don hang" << endl;
	ReceiptFactory::instance()->listAll();
}