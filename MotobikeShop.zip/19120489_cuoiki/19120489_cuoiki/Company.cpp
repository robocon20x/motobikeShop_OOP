#include"Company.h"

Company::Company() = default;

Company::Company(string name, vector<Model> models)
{
	_company = name;
	_models = models;
}

string Company::getCompany() { 
	return _company; 
}

vector<Model> Company::getModels() { 
	return _models; 
}

void Company::setCompany(string name)
{
	_company = name;
}

void Company::setModels(vector<Model> model)
{
	_models = model;
}

ostream& operator<< (ostream& o, const Company& c)
{
	o << c._company;
	return o;
}