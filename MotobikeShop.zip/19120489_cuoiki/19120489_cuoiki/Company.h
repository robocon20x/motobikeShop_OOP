#pragma once
#include<string>
#include<iostream>
#include<sstream>
#include<memory>
#include<fstream>
#include<vector>
#include<iomanip>
#include "Tokenizer.h"
#include "Model.h"

class Company
{
private:
	string _company;
	vector<Model> _models;
public:
	Company();
	Company(string, vector<Model>);

	void setModels(vector<Model>);
	vector<Model> getModels();
	void setCompany(string);
	string getCompany();

	friend ostream& operator<< (ostream&, const Company&);
};
