#include"Menu.h"

int main() {
	int choice;
	do {
		Menu::MenuList();
		cin >> choice;
		Menu::selectChoice(choice);
	} 	while (choice != 4);

	return 0;
}