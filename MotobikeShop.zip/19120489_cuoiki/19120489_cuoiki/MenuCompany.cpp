#include"MenuCompany.h"

void MenuCompany::MenuList() {
	system("cls");
	cout << "1. Danh sach cac hang xe" << endl;
	cout << "2. Them hang xe" << endl;
	cout << "3. Sua ten hang xe" << endl;
	cout << "4. Xoa hang xe" << endl;
	cout << "5. Xem cac model cua hang xe" << endl;
	cout << "6. Them xe" << endl;
	cout << "7. Sua thong tin xe" << endl;
	cout << "8. Xoa xe" << endl;
	cout << "9. Danh sach xe cua tung hang" << endl;
	cout << "10. Quay lai" << endl;
	cout << "Lua chon: ";
}

void MenuCompany::selectChoice(int choice) {
	switch (choice) {
	case 1: {
		listCompany();
		break;
	}
	case 2: {
		addCompany();
		break;
	}
	case 3: {
		setCompany();
		break;
	}
	case 4: {
		deleteCompany();
		break;
	}
	case 5: {
		listModel();
		break;
	}
	case 6: {
		addMotorbike();
		break;
	}
	case 7: {
		setMotorbike();
		break;
	}
	case 8: {
		deleteMotorbike();
		break;
	}
	case 9: {
		listAll();
		break;
	}
	case 10: {
		system("cls");
		break;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choice;
	}
	}
}

void MenuCompany::listCompany() {
	system("cls");
	cout << "Danh sach cac hang xe : " << endl;
	CompanyFactory::instance()->listCompany();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
		break;
	}

	}
	system("cls");
}
void MenuCompany::addCompany() {

	system("cls");

	cout << "Danh sach cac hang:" << endl;
	CompanyFactory::instance()->listCompany();

	string company;
	cout << "\nNhap ten hang xe muon them: ";
	cin >> company;
	int flag1 = 1;
	while (CompanyFactory::instance()->findCompany(company) != -1)
	{
		cout << "Hang " << company << " da ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> company;
		}
		else if (flag1 == 2) return;
		else return;
	}

	cin.ignore();
	CompanyFactory::instance()->addCompany(company);
	system("cls");
	cout << "Danh sach cac hang : " << endl;
	CompanyFactory::instance()->listCompany();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
		break;
	}
	}
	system("cls");
}

void MenuCompany::setCompany() {
	string old;
	string update;
	system("cls");
	cout << "Danh sach cac hang : " << endl;
	CompanyFactory::instance()->listCompany();
	cout << "Nhap ten hang ban muon sua: ";
	cin >> old;
	int flag1 = 1;
	while (CompanyFactory::instance()->findCompany(old) == -1)
	{
		cout << "Hang " << old << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> old;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cout << "Nhap ten moi " << endl;
	cin >> update;
	flag1 = 1;
	while (CompanyFactory::instance()->findCompany(update) != -1)
	{
		cout << "Ten " << update << " da ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> update;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	CompanyFactory::instance()->setCompany(old, update);
	system("cls");
	cout << "Danh sach cac hang : " << endl;
	CompanyFactory::instance()->listCompany();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
	system("cls");
}

void MenuCompany::deleteCompany() {

	system("cls");
	CompanyFactory::instance()->listCompany();
	string company;
	int flag1 = 1;
	cout << "Nhap ten hang xe ban muon xoa: ";
	cin >> company;
	while (CompanyFactory::instance()->findCompany(company) == -1)
	{
		cout << "Hang " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> company;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();

	CompanyFactory::instance()->deleteCompany(company);
	system("cls");
	cout << "Danh sach cac hang xe : " << endl;
	CompanyFactory::instance()->listCompany();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
	system("cls");
}

void MenuCompany::listModel() {
	system("cls");

	CompanyFactory::instance()->listCompany();
	string company;

	cout << "Nhap ten hang xe: ";
	cin >> company;
	int flag1 = 1;
	while (CompanyFactory::instance()->findCompany(company) == -1)
	{
		cout << "Hang " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin>>company;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	system("cls");
	cout << "Danh sach cac hang xe " << company <<": "<<endl;
	CompanyFactory::instance()->listModel(company);

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
	system("cls");
}

void MenuCompany::addMotorbike() {
	bool notexisted = false;
	string company;
	string model;
	system("cls");

	cout << "Danh sach hang xe" << endl;
	CompanyFactory::instance()->listCompany();

	cout << "Nhap ten hang ban muon them xe : ";
	cin >> company;
	int flag1 = 1;
	while (CompanyFactory::instance()->findCompany(company) == -1) {
		cout << "Hang " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> company;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();

	system("cls");

	cout << "Danh sach xe cua hang " << company << " la:" << endl;
	CompanyFactory::instance()->listModel(company);
	flag1 = 1;
	cout << "Nhap ten xe them vao : " << endl;
	while (!notexisted)
	{
		getline(cin, model);
		while (!Model::isModel(model))
		{
			cout << "Ten xe " << model << " khong dung" << endl;;//check
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		if (CompanyFactory::instance()->findModel(company, model) != -1)
		{
			cout << "Ten " << model << " da ton tai"<<endl;//check
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
			}
			else if (flag1 == 2) return;
			else return;
		}
		else notexisted = true;
	}

	vector<string>tokens = Tokenizor::split(model, " ");
	Model m(tokens[0], tokens[1]);
	CompanyFactory::instance()->addModel(company, m);
	MotorbikeFactory::instance()->addModel(company, m);
	system("cls");
	cout << "Danh sach xe cua hang " << company << ": " << endl;
	CompanyFactory::instance()->listModel(company);

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
	system("cls");
}

void MenuCompany::setMotorbike() {
	bool existed = false;
	string company;
	string model;
	string update;
	system("cls");

	cout << "Danh sach hang xe" << endl;
	CompanyFactory::instance()->listCompany();
	cout << "Nhap ten hang xe can sua : ";
	cin >> company;
	int flag1 = 1;
	while (CompanyFactory::instance()->findCompany(company) == -1)
	{
		cout << "Hang " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> company;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();

	system("cls");

	cout << "Danh sach xe cua hang " << company << " la:" << endl;
	CompanyFactory::instance()->listModel(company);

	cout << "Nhap ten xe can sua: " << endl; //check
	cout << " VD: RSX 2020, vision 2021" << endl;
	while (!existed)
	{
		getline(cin, model);
		while (!Model::isModel(model))
		{
			cout << "Ten xe " << model << " khong dung" << endl;;//check
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		if (CompanyFactory::instance()->findModel(company, model) == -1)
		{
			cout << "Ten xe " << model << " khong ton tai" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
			}
			else if (flag1 == 2) return;
			else return;
		}
		else existed = true;
	}

	bool notexisted = false;
	cout << "Nhap ten moi cua xe : " << endl;
	while (!notexisted)
	{
		getline(cin, update);
		while (!Model::isModel(update))
		{
			cout << "Ten xe " << update << " khong dung" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		if (CompanyFactory::instance()->findModel(company, update) != -1)
		{
			cout << "Ten xe " << update << " da ton tai" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
			}
			else if (flag1 == 2) return;
			else return;
		}
		else notexisted = true;
	}

	vector<string>tokens = Tokenizor::split(model, " ");
	Model old(tokens[0], tokens[1]);
	vector<string>t = Tokenizor::split(update, " ");
	Model New(t[0], t[1]);
	CompanyFactory::instance()->setModel(company, old, New);
	MotorbikeFactory::instance()->setModel(company, old, New);

	system("cls");
	cout << "Danh sach cac xe " << company << ": " << endl;
	CompanyFactory::instance()->listModel(company);

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
	system("cls");
}

void MenuCompany::deleteMotorbike() {
	bool notexisted = false;
	string company;
	string model;

	system("cls");

	cout << "Danh sach hang xe" << endl;
	CompanyFactory::instance()->listCompany();
	cout << "Nhap ten xe can xoa : " << endl;
	cin >> company;
	int flag1 = 1;
	while (CompanyFactory::instance()->findCompany(company) == -1)
	{
		cout << "Hang xe " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> company;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();

	system("cls");

	cout << "Danh sach xe cua hang " << company << " la:" << endl;
	CompanyFactory::instance()->listModel(company);

	cout << "Nhap ten xe can xoa: " << endl;
	while (!notexisted)
	{
		getline(cin, model);
		while (!Model::isModel(model))
		{
			cout << "Ten xe " << model << " khong dung" << endl;;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		if (CompanyFactory::instance()->findModel(company, model) == -1)
		{
			cout << "Ten xe " << model << " khong ton tai" << endl;;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
			}
			else if (flag1 == 2) return;
			else return;
		}
		else notexisted = true;
	}

	vector<string>tokens = Tokenizor::split(model, " ");
	Model old(tokens[0], tokens[1]);

	CompanyFactory::instance()->deleteModel(company, old);
	MotorbikeFactory::instance()->deleteModel(company, old);

	system("cls");
	cout << "Danh sach cac xe " << company << ": " << endl;
	CompanyFactory::instance()->listModel(company);

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
	system("cls");
}

void MenuCompany::listAll() {
	system("cls");
	cout << "Danh sach hang xe va xe: " << endl;
	CompanyFactory::instance()->listAll();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}