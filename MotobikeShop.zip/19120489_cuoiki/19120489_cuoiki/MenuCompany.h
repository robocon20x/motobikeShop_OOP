#pragma once
#include"CompanyFactory.h"
#include"MotorbikeFactory.h"

class MenuCompany {
public:
	static void MenuList();
	static void selectChoice(int);

	static void listCompany();
	static void addCompany();
	static void setCompany();
	static void deleteCompany();

	static void listModel();

	static void addMotorbike();
	static void setMotorbike();
	static void deleteMotorbike();

	static void listAll();

};