#include"Model.h"

Model::Model() = default;

Model::Model(string name, string version) {
	_name = name;
	_version = version;
}

string Model::getName() { 
	return _name; 
}
void Model::setName(string name) { 
	_name = name; 
}
string Model::getVersion() {
	return _version;
}
void Model::setVersion(string version) {
	_version = version;
}

string Model::toString() {
	stringstream builder;
	builder << _name << "|" << _version;
	return builder.str();
}

bool Model::isModel(string buffer)
{
	vector<string>tokens = Tokenizor::split(buffer, " ");
	if (tokens.size() != 2)
		return false;

	return true;
}

string Model::getModelName() {
	stringstream builder;
	builder << _name << " " << _version;
	return builder.str();
}
ostream& operator<< (ostream& o, const Model& m)
{
	o << m._name << " " << m._version;
	return o;
}

Model Model::parse(string buffer, string needle)
{
	vector<string>tokens = Tokenizor::split(buffer, needle);
	Model result(tokens[0], tokens[1]);
	return result;
}