#include "Motorbike.h"

Motorbike::Motorbike() = default;

Motorbike::Motorbike(string company, Model model, string costPrice, string sellPrice, int quantity) {
	_company = company;
	_model = model;
	_costPrice = costPrice;
	_sellPrice = sellPrice;
	_quantity = quantity;
}

string Motorbike::getCompany() {
	return _company;
}
void Motorbike::setCompany(string company) {
	_company = company;
}

Model Motorbike::getModel() {
	return _model;
}
void Motorbike::setModel(Model model) {
	_model = model;
}

string Motorbike::getCostPrice() {
	return _costPrice;
}
void Motorbike::setCostPrice(string costPrice) {
	_costPrice = costPrice;
}

string Motorbike::getSellPrice() {
	return _sellPrice;
}
void Motorbike::setSellPrice(string sellPrice) {
	_sellPrice = sellPrice;
}

int Motorbike::getQuantity() {
	return _quantity;
}
void Motorbike::setQuantity(int quantity) {
	_quantity = quantity;
}

string Motorbike::toString() {
	stringstream writer;
	writer << _company << " " << _model.toString() << " "
		<< _costPrice << " " << _sellPrice << " " << _quantity;
	return writer.str();
}

bool Motorbike::isMotorbike(string buffer)
{
	vector<string>tokens = Tokenizor::split(buffer, " ");
	if (tokens.size() != 3)
		return false;

	return true;
}

Motorbike Motorbike::parse(string buffer) {
	vector<string>tokens = Tokenizor::split(buffer, " ");

	string company = tokens[0];
	Model model = Model::parse(tokens[1], "|");
	string costPrice = tokens[2];
	string sellPrice = tokens[3];
	int quantity = stoi(tokens[4]);

	Motorbike result(company, model, costPrice, sellPrice, quantity);
	return result;
}

ostream& operator<< (ostream& o, const Motorbike& m)
{
	o << m._company << " " << m._model << " "
		<< m._costPrice << " " <<m._sellPrice << " " << m._quantity;
	return o;
}