#pragma once
#include"MenuEditReceipt.h"

class MenuReceipt {
public:
	static void MenuList();
	static void selectChoice(int);

	static void listReceiptofMonth();
	static void listReceiptAll();
	static void setReceipt();
	static void deleteReceipt();
};