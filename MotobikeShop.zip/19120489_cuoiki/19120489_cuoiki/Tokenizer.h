#pragma once
#include<vector>
#include<string>
#include<sstream>

using namespace std;
class Tokenizor {
public:
    static vector<string> split(string haystack, string needed);
};