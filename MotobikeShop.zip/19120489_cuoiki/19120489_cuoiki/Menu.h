#pragma once
#include"MenuCompany.h"
#include"MenuEditReceipt.h"
#include"MenuReceipt.h"
#include"MenuReport.h"

class Menu {
public:
	static void MenuList();
	static void selectChoice(int);
};