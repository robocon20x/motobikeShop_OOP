#pragma once
#include<string>
#include<iostream>
#include<sstream>
#include<memory>
#include<fstream>
#include<vector>
#include<iomanip>
#include "Tokenizer.h"

using namespace std;

class Model {
private:
	string _name;
	string _version;
public:
	Model();
	Model(string, string);

	string getName();
	void setName(string);
	//string getColor();
	//void setColor(string);
	string getVersion();
	void setVersion(string);
	string getModelName();

	static bool isModel(string);

	string toString();
	static Model parse(string buffer, string needle);

	friend ostream& operator<< (ostream&, const Model&);
};