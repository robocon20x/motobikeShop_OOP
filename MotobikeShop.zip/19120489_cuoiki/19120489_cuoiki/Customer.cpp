#include"Customer.h"

Customer::Customer() = default;

Customer::Customer(string name, string phonenumber, string email, string address) {
	_name = name;
	_phonenumber = phonenumber;
	_email = email;
	_address = address;
}

string Customer::getName() {
	return _name;
}
void Customer::setName(string name) {
	_name = name;
}

string Customer::getPhone() {
	return _phonenumber;
}
void Customer::setPhone(string phone) {
	_phonenumber = phone;
}

string Customer::getEmail() {
	return _email;
}
void Customer::setEmail(string email) {
	_email = email;
}

string Customer::getAddress() {
	return _address;
}
void Customer::setAddress(string address) {
	_address = address;
}

string Customer::toString() {
	stringstream writer;
	writer << _name << "#" << _phonenumber << "#" << _email << "#" << _address;
	return writer.str();
}

ostream& operator<<(ostream& o, const Customer& c) {
	o << " + Ho va ten: " << c._name << endl;
	o << " + SDT      : " << c._phonenumber << endl;
	o << " + Email    : " << c._email << endl;
	o << " + Dia chi  : " << c._address;
	return o;
}

Customer Customer::parse(string buffer) {
	vector<string>tokens = Tokenizor::split(buffer, "#");
	string name = tokens[0];
	string phonenumber = tokens[1];
	string email = tokens[2];
	string address = tokens[3];
	Customer temp(name, phonenumber, email, address);
	return temp;
}