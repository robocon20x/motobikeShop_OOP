#include"MenuReport.h"

void MenuReport::MenuList() {
	system("cls");
	cout << "1. Kiem tra kho hang " << endl;
	cout << "2. Chinh so luong xe trong kho " << endl;
	cout << "3. Hien gia von va gia ban tat ca xe trong kho " << endl;
	cout << "4. Chinh sua gia von va gia ban" << endl;
	cout << "5. Hien thi danh sach cac xe sap het (so luong < 10) " << endl;
	cout << "6. Hien thi xe ban nhieu nhat trong thang" << endl;
	cout << "7. Hien thi xe ban nhieu nhat" << endl;
	cout << "8. Doanh thu moi thang " << endl;
	cout << "9. Doanh thu tong" << endl;
	cout << "10. Quay lai" << endl;
	cout << "Lua chon: ";
}

void MenuReport::selectChoice(int choice) {
	switch (choice) {
	case 1: {
		Inventory();
		break;
	}
	case 2: {
		setQuantity();
		break;
	}
	case 3: {
		listAll();
		break;
	}
	case 4: {
		setPrice();
		break;
	}
	case 5: {
		outofStock();
		break;
	}
	case 6: {
		listBestSellofMonth();
		break;
	}
	case 7: {
		listBestSellAll();
		break;
	}
	case 8: {
		incomeMonth();
		break;
	}
	case 9: {
		incomeAll();
		break;
	}
	case 10: {
		system("cls");
		break;
	}

	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choice;
	}
	}
}

void MenuReport::Inventory() {
	system("cls");
	cout << "Kho hang : " << endl;
	MotorbikeFactory::instance()->inventory();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}
	}
	system("cls");
}

void MenuReport::setQuantity() {
	bool notexisted = false;
	string company;
	string model;
	system("cls");

	cout << "Danh sach cac hang xe : " << endl;
	CompanyFactory::instance()->listCompany();

	int flag = 1;
	cout << "Nhap ten hang cua xe can sua : " << endl;
	cin >> company;
	while (CompanyFactory::instance()->findCompany(company) == -1)
	{
		cout << "Hang " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai " << endl;
		cout << "2. Quay lai " << endl;
		cout << "Lua chon: ";
		cin >> flag;
		if (flag == 1) cin >> company;
		else if (flag == 2) return;
		else return;
	}
	cin.ignore();

	system("cls");
	cout << "Danh sach cac hang xe " << company << ": " << endl;
	CompanyFactory::instance()->listModel(company);

	cout << "Nhap ten xe can chinh so luong: " << endl;
	while (!notexisted)
	{	
		getline(cin, model);
		int flag1 = 1;
		while (!Model::isModel(model))
		{
			cout << "Ten xe " << model << " khong dung" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) { 
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		if (CompanyFactory::instance()->findModel(company, model) == -1)
		{
			cout << "Ten " << model << " khong ton tai" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag;
			if (flag == 1) continue;
			else if (flag == 2) return;
			else return;
		}
		else notexisted = true;
	}

	int number;
	cout << "Nhap so luong moi " << endl;
	cin >> number;
	while (number < 0)
	{
		cout << "So luong khong phu hop, nhap lai: " << endl;
		cin >> number;
	}
	cin.ignore();
	vector<string>tokens = Tokenizor::split(model, " ");
	Model old(tokens[0], tokens[1]);
	MotorbikeFactory::instance()->editInventory(company, old, number);

	system("cls");
	cout << "kho hang: " << endl;
	MotorbikeFactory::instance()->inventory();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuReport::listAll() {
	system("cls");
	cout << "gia goc va gia ban cua xe : " << endl;
	MotorbikeFactory::instance()->listPrice();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuReport::setPrice() {
	bool notexisted = false;
	string company;
	string model;

	system("cls");

	cout << "Danh sach hang xe" << endl;
	CompanyFactory::instance()->listCompany();
	cout << "Nhap ten hang cua xe can sua gia: " << endl;
	cin >> company;
	int flag = 1;
	while (CompanyFactory::instance()->findCompany(company) == -1)
	{
		cout << "Hang " << company << " khong ton tai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag;
		if (flag == 1) cin >> company;
		else if (flag == 2) return;
		else return;
	}
	cin.ignore();

	system("cls");

	cout << "Danh sach xe cua hang " << company << " la: " << endl;
	CompanyFactory::instance()->listModel(company);

	cout << "Nhap ten xe can sua gia : " << endl;
	while (!notexisted)
	{
		int flag1 = 1;
		getline(cin, model);
		while (!Model::isModel(model))
		{
			cout << "Ten xe " << model << " khong dung" << endl;;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		if (CompanyFactory::instance()->findModel(company, model) == -1)
		{
			cout << "Ten xe " << model << " khong ton tai" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
			}
			else if (flag1 == 2) return;
			else return;
		}
		else notexisted = true;
	}

	int costprice, price;
	cout << "Nhap gia von moi " << endl;
	cin >> costprice;
	flag = 1;
	while (costprice < 0)
	{
		cout << "Gia von khong hop le" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag;
		if (flag == 1) cin >> costprice;
		else if (flag == 2) return;
		else return;
	}
	cout << "Nhap gia ban moi " << endl;
	cin >> price;
	flag = 1;
	while (price < 0)
	{
		cout << "Gia ban khong hop le" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag;
		if (flag == 1) cin >> price;
		else if (flag == 2) return;
		else return;
	}
	cin.ignore();
	vector<string>tokens = Tokenizor::split(model, " ");
	Model old(tokens[0], tokens[1]);
	MotorbikeFactory::instance()->setPrice(company, old, to_string(costprice), to_string(price));
	system("cls");
	cout << "Bang gia : " << endl;
	MotorbikeFactory::instance()->listPrice();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
}

void MenuReport::outofStock() {
	system("cls");
	cout << "Danh sach cac mat hang sap het(so luong < 10) : " << endl;
	MotorbikeFactory::instance()->AbouttoRunOutProduct();

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
}

void MenuReport::listBestSellofMonth() {
	system("cls");
	int month;
	int thisMonth = Time::currentMonth();
	cout << "Thang hien tai la: " << thisMonth << endl;
	cout << "Nhap thang ban muon xem" << endl;
	cin >> month;
	while (month > thisMonth || month < 1)
	{
		cout << "Thang ban nhap khong hop le" << endl;
		cin >> month;
	}
	cin.ignore();
	cout << "Danh sach 10 mat hang ban chay nhat thang " << month << " : " << endl;
	ReceiptFactory::instance()->listBestSellofMonth(month);

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}
}

void MenuReport::listBestSellAll() {
	system("cls");
	cout << "Danh sach 10 mat hang ban chay nhat: " << endl;
	ReceiptFactory::instance()->listBestSell();
}

void MenuReport::incomeMonth() {
	system("cls");
	int month;
	int thisMonth = Time::currentMonth();
	cout << "Thang hien tai la: " << thisMonth << endl;
	cout << "Nhap thang ban muon xem" << endl;
	cin >> month;
	while (month > thisMonth || month < 1)
	{
		cout << "Thang ban nhap khong hop le" << endl;
		cin >> month;
	}
	cin.ignore();
	cout << "Doanh thu, loi nhuan thang " << month << " : " << endl;
	ReceiptFactory::instance()->incomeOfMonth(month);
}

void MenuReport::incomeAll() {
	system("cls");
	cout << "Doanh thu, loi nhuan : " << endl;
	ReceiptFactory::instance()->income();
}