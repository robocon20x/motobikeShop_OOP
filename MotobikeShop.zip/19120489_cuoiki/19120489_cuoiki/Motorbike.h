#pragma once
#include<iostream>
#include<sstream>
#include<memory>
#include<fstream>
#include<vector>
#include<string>
#include<iomanip>
#include "Tokenizer.h"
#include "Model.h"
#include "Company.h"
#include "CompanyFactory.h"

using namespace std;

class Motorbike {
private:
	string _company;
	Model _model;
	string _costPrice;
	string _sellPrice;
	int _quantity;
public:
	Motorbike();
	Motorbike(string, Model, string, string, int);

	string getCompany();
	void setCompany(string);

	Model getModel();
	void setModel(Model);

	string getCostPrice();
	void setCostPrice(string);

	string getSellPrice();
	void setSellPrice(string);

	int getQuantity();
	void setQuantity(int);

	static bool isMotorbike(string);

	string toString();
	static Motorbike parse(string buffer);

	friend ostream& operator<< (ostream&, const Motorbike&);
};