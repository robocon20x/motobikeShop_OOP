#pragma once
#include"CompanyFactory.h"
#include"MotorbikeFactory.h"
#include"ReceiptFactory.h"

class MenuReport {
public:
	static void MenuList();
	static void selectChoice(int);

	static void Inventory();
	static void setQuantity();

	static void listAll();
	static void setPrice();

	static void outofStock();

	static void listBestSellofMonth();
	static void listBestSellAll();

	static void incomeMonth();
	static void incomeAll();
};