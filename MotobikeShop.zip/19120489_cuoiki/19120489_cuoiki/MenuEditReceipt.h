#pragma once
#include"CompanyFactory.h"
#include"MotorbikeFactory.h"
#include"ReceiptFactory.h"

class MenuEditReceipt {
public:
	static void MenuList();
	static void selectChoice(int);

	static void setCustomerName();
	static void setCustomerPhone();
	static void setCustomerEmail();
	static void setCustomerAddress();

	static void setTime();
	static void setModelandQuantity();
};
