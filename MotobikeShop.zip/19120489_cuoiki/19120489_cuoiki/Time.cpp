#include"Time.h"

Time::Time() {
	_day = 0;
	_month = 0;
	_year = 0;
}

Time::Time(int day, int month, int year) {
	_day = day;
	_month = month;
	_year = year;
}

int Time::getDay() {
	return _day;
}
void Time::setDay(int day) {
	_day = day;
}

int Time::getMonth() {
	return _month;
}
void Time::setMonth(int month) {
	_month = month;
}

int Time::getYear() {
	return _year;
}
void Time::setYear(int year) {
	_year = year;
}

string Time::toString() {
	stringstream writer;
	if (_day < 10) writer << 0;
	writer << _day << "/";

	if (_month < 10) writer << 0;
	writer << _month << "/";

	writer << _year;

	return writer.str();
}

int Time::currentYear() {
	time_t now = time(NULL);
	tm ltm;
	localtime_s(&ltm, &now);
	return  1900 + ltm.tm_year;
}

int Time::currentMonth() {
	time_t now = time(NULL);
	tm ltm;
	localtime_s(&ltm, &now);
	return  1 + ltm.tm_mon;
}

bool isValid(int day, int month, int year) {
	int days[] = { -1, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	if (year < 0) return false;
	if (month < 0 || month > 12) return false;
	if (day < 0 || day > days[month]) return false;
	if (day == 29 && month == 2 && (year % 400 == 0 || year % 100 == 0 || year % 4 != 0)) return false;

	return true;
}

Time Time::parse(string buffer) {
	vector<string>tokens = Tokenizor::split(buffer, "/");
	int day = stoi(tokens[0]);
	int month = stoi(tokens[1]);
	int year = stoi(tokens[2]);
	Time result(day, month, year);
	return result;
}

ostream& operator<<(ostream& builder, const Time& time) {
	if (time._day < 10) builder << "0";
	builder << time._day << "/";
	if (time._month < 10) builder << "0";
	builder << time._month << "/" << time._year;
	return builder;
}

