#include"CompanyFactory.h"

//CompanyFactory* CompanyFactory::_instance = NULL;

CompanyFactory* CompanyFactory::instance() {
    if (_instance == NULL) {
        _instance = new CompanyFactory();
    }
    return _instance;
}

CompanyFactory::CompanyFactory() {
    ifstream filein("Company.txt");

    int countCompanys, countModels;
    string companys, models;

    filein >> countCompanys;
    filein.ignore();
    for (int i = 0; i < countCompanys; i++)
    {
        getline(filein, companys);
        filein >> countModels;
        filein.ignore();
        vector<Model> modelStore;
        for (int j = 0; j < countModels; j++)
        {
            getline(filein, models);
            Model m = Model::parse(models, "|");
            modelStore.push_back(m);
        }
        Company b(companys, modelStore);
        _prototypes.push_back(b);
    }
    filein.close();
}

int CompanyFactory::total() {
    return _prototypes.size();
}

Company CompanyFactory::creatCompany(string type) {
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (type == _prototypes[i].getCompany())
        {
            return _prototypes[i];
        }
    }
}

int CompanyFactory::findCompany(string company) {
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (company == _prototypes[i].getCompany())
        {
            return i;
        }
    }
    return -1;
}

int CompanyFactory::findModel(string company, Model model) {
    int pos = findCompany(company);
    if (pos == -1) return -1;
    vector<Model> models = _prototypes[pos].getModels();
    for (int i = 0; i < models.size(); i++)
    {
        if (model.getName() == models[i].getName() && model.getVersion() == models[i].getVersion())
            return i;
    }
    return -1;
}

int CompanyFactory::findModel(string company, string model) {
    int pos = findCompany(company);
    if (pos == -1) return -1;

    vector<string>tokens = Tokenizor::split(model, " ");

    vector<Model> models = _prototypes[pos].getModels();
    for (int i = 0; i < models.size(); i++)
    {
        if (tokens[0] == models[i].getName() && tokens[1] == models[i].getVersion())
            return i;
    }
    return -1;
}

void CompanyFactory::listCompany() {
    for (int i = 0; i < _prototypes.size(); i++)
    {
        cout << i + 1 << ". " << _prototypes[i].getCompany() << endl;
    }

}

void CompanyFactory::listAll() {
    string company;
    for (int i = 0; i < _prototypes.size(); i++)
    {
        company = _prototypes[i].getCompany();
        cout << "+ " << company << endl;
        vector<Model> models = _prototypes[i].getModels();
        for (int j = 0; j < models.size(); j++)
        {
            cout << j + 1 << ". " << company << " " << models[j] << endl;
        }
    }
    cout << endl;

}

void CompanyFactory::listModel(string company) {
    for (int i = 0; i < _prototypes.size(); i++)
    {
        if (company == _prototypes[i].getCompany())
        {
            cout << company << endl;
            vector<Model> models = _prototypes[i].getModels();
            for (int j = 0; j < models.size(); j++)
            {
                cout << j + 1 << ". " << company << " " << models[j] << endl;
            }
        }
    }
    cout << endl;
  /*  int choose = 0;
    cout << "Tuy chon:" << endl;
    cout << "1.Quay lai menu" << endl;
    cout << "Nhap lua chon: ";
    cin >> choose;
    switch (choose) {
    case 1: {
        return;
    }
    default: {
        cout << "nhap sai lua chon" << endl;
        cout << "nhap lai lua chon: ";
        cin >> choose;
    }

    }
    system("cls");*/
}

void CompanyFactory::addCompany(string company) {
    vector<Model> models;
    Company b(company, models);
    _prototypes.push_back(b);
    update();
}

void CompanyFactory::addCompany(string company, vector<Model> models)
{
    Company b(company, models);
    _prototypes.push_back(b);
    update();
}

void CompanyFactory::addModel(string company, Model model) {
    int companypos = findCompany(company);

    if (companypos == -1)
    {
        cout << "Hang xe " << company << " khong ton tai !";
        return;
    }
    if (findModel(company, model) != -1)
    {
        cout << "model " << company << " " << model << " da ton tai !";
        return;
    }
    vector<Model> temp = _prototypes[companypos].getModels();
    temp.push_back(model);
    _prototypes[companypos].setModels(temp);
    update();
}

void CompanyFactory::setCompany(string pos, string pre) {
    int companypos = findCompany(pos);

    _prototypes[companypos].setCompany(pre);
    update();
}

void CompanyFactory::setModel(string company, Model pos, Model pre) {

    int companypos = findCompany(company);

    int modelpos = findModel(company, pos);
    //check
    if (companypos == -1)
    {
        cout << "Hang xe " << company << " khong ton tai !";
        return;
    }
    if (modelpos == -1)
    {
        cout << "Model " << company << " " << pos << " khong ton tai !";
        return;
    }
    //set
    vector<Model> temp = _prototypes[companypos].getModels();
    temp[modelpos] = pre;
    _prototypes[companypos].setModels(temp);

    update();
}

void CompanyFactory::deleteCompany(string company) {
    int companypos = findCompany(company);

    _prototypes.erase(_prototypes.begin() + companypos);
    update();
}

void CompanyFactory::deleteModel(string company, Model model) {
    // position of needed company in vector
    int companypos = findCompany(company);
    //  position of needed model in vector
    int modelpos = findModel(company, model);
    if (companypos == -1)
    {
        cout << "Hang Laptop " << company << " ban muon xoa khong ton tai !";
        return;
    }
    if (modelpos == -1)
    {
        cout << "Dong Laptop " << company << " " << model << " ban muon xoa khong ton tai !";
        return;
    }
    vector<Model> temp = _prototypes[companypos].getModels();
    temp.erase(temp.begin() + modelpos);
    _prototypes[companypos].setModels(temp);
    update();
}

void CompanyFactory::update() {
    ofstream fileout("Company.txt");
    fileout << _prototypes.size() << endl;
    string company;
    for (int i = 0; i < _prototypes.size(); i++)
    {
        company = _prototypes[i].getCompany();
        fileout << company << endl;
        vector<Model> models = _prototypes[i].getModels();
        fileout << models.size() << endl;
        for (int j = 0; j < models.size(); j++)
        {
            fileout << models[j].toString() << endl;
        }
    }
    fileout.close();
}