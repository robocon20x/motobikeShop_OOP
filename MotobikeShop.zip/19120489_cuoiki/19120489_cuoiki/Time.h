#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<string>
#include<sstream>
#include<iostream>
#include<ctime>
#include<iostream>
#include"Tokenizer.h"
#include<iomanip>

class Time {
private:
	int _day;
	int _month;
	int _year;
public:
	Time();
	Time(int day, int month, int year);
	int getDay();
	void setDay(int);
	int getMonth();
	void setMonth(int);
	int getYear();
	void setYear(int);

	string toString();
	bool isValid(int day, int month, int year);

	static int currentYear();
	static int currentMonth();

	static Time parse(string buffer);
	friend ostream& operator<<(ostream&, const Time&);
};