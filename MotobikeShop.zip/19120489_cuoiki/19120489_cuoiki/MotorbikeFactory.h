#pragma once
#include<iostream>
#include <stdio.h>
#include <conio.h>
#include<sstream>
#include<memory>
#include<fstream>
#include<vector>
#include<string>
#include "Tokenizer.h"
#include "Company.h"
#include "Model.h"
#include "CompanyFactory.h"
#include "Motorbike.h"

using namespace std;

class MotorbikeFactory
{
private:
	inline static MotorbikeFactory* _instance = NULL;
	vector<Motorbike> _prototypes;
	MotorbikeFactory();
public:
	static MotorbikeFactory* instance();
	int total();
	Motorbike motorbikeModel(int pos);
	Motorbike createMotorbike(string, Model);

	bool isExists(string);
	bool isExists(string, Model);

	void setCompany(string, string);
	void deleteCompany(string);

	void addModel(string, Model);
	void setModel(string, Model, Model);
	void deleteModel(string, Model);

	void listPrice();
	void setPrice(string, Model, string, string);

	void inventory();
	void editInventory(string, Model, int);

	void AbouttoRunOutProduct(); // hien san pham

	void update();
};

