#pragma once
#include"Receipt.h"

class ReceiptFactory {
private:
	inline static ReceiptFactory* _instance = NULL;
	vector<Receipt> _prototypes;
	ReceiptFactory();
public:
	static ReceiptFactory* instance();
	int total();

	int findReceipt(string);
	void deleteReceipt(string);
	Receipt getReceipt(string);

	void setCustomerName(Receipt&, string);
	void setCustomerAddress(Receipt&, string);
	void setCustomerPhone(Receipt&, string);
	void setCustomerEmail(Receipt&, string);

	void setTime(Receipt&, string);
	void editItem(Receipt&, int, string, int);

	void listAll();
	void listReceiptofMonth(int);
	void listBestSellofMonth(int);
	void listBestSell();

	void incomeOfMonth(int);
	void income();

	void update();
};