#include"MenuEditReceipt.h"

void MenuEditReceipt::MenuList() {
	cout << "1. Sua ho va ten khach hang " << endl;
	cout << "2. Sua so dien thoai khach hang " << endl;
	cout << "3. Sua dia chi khach hang " << endl;
	cout << "4. Sua email khach hang " << endl;
	cout << "5. Sua ngay mua hang  " << endl;
	cout << "6. Sua ten xe va so luong" << endl;
	cout << "7. Quay lai" << endl;
	cout << "Lua chon: ";
}
void MenuEditReceipt::selectChoice(int choice) {
	switch (choice) {
	case 1: {
		setCustomerName();
		break;
	}
	case 2: {
		setCustomerPhone();
		break;
	}
	case 3: {
		setCustomerAddress();
		break;
	}
	case 4: {
		setCustomerEmail();
		break;
	}
	case 5: {
		setTime();
		break;
	}
	case 6: {
		setModelandQuantity();
		break;
	}
	case 7: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choice;
	}
	}
}

void MenuEditReceipt::setCustomerName() {
	string code;
	system("cls");
	cout << "Nhap ma don hang cua don hang chinh sua: " << endl;
	cin >> code;
	int flag1 = 1;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	cout << endl;
	Receipt receipt = ReceiptFactory::instance()->getReceipt(code);
	cout << receipt.toString();
	cout << endl;
	string fullname;
	cout << "Nhap ho va ten moi: " << endl;
	getline(cin, fullname);
	
	ReceiptFactory::instance()->setCustomerName(receipt, fullname);

	system("cls");
	cout << "Don hang sau khi cap nhat :" << endl;
	cout << receipt.toString();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuEditReceipt::setCustomerPhone() {
	string code;
	system("cls");
	cout << "Nhap ma don hang cua don hang chinh sua: " << endl;
	cin >> code;
	int flag1 = 1;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	cout << endl;
	Receipt receipt = ReceiptFactory::instance()->getReceipt(code);
	cout << receipt.toString();
	cout << endl;
	string phone;
	cout << "So dien thoai moi: " << endl;
	getline(cin, phone);

	ReceiptFactory::instance()->setCustomerPhone(receipt, phone);

	system("cls");
	cout << "Don hang sau khi cap nhat :" << endl;
	cout << receipt.toString();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuEditReceipt::setCustomerEmail() {
	string code;
	system("cls");
	cout << "Nhap ma don hang cua don hang chinh sua: " << endl;
	cin >> code;
	int flag1 = 1;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	cout << endl;
	Receipt receipt = ReceiptFactory::instance()->getReceipt(code);
	cout << receipt.toString();
	cout << endl;
	string email;
	cout << "Nhap email moi: " << endl;
	getline(cin, email);

	ReceiptFactory::instance()->setCustomerEmail(receipt, email);
	system("cls");
	cout << "Don hang sau khi cap nhat :" << endl;
	cout << receipt.toString();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuEditReceipt::setCustomerAddress() {
	string code;
	system("cls");
	cout << "Nhap ma don hang cua don hang chinh sua: " << endl;
	cin >> code;
	int flag1 = 1;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	cout << endl;
	Receipt receipt = ReceiptFactory::instance()->getReceipt(code);
	cout << receipt.toString();
	cout << endl;
	string address;
	cout << "Nhap dia chi moi: " << endl;
	getline(cin, address);

	ReceiptFactory::instance()->setCustomerAddress(receipt, address);
	system("cls");
	cout << "Don hang sau khi cap nhat :" << endl;
	cout << receipt.toString();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuEditReceipt::setTime() {
	string code;
	system("cls");
	cout << "Nhap ma don hang cua don hang chinh sua: " << endl;
	cin >> code;
	int flag1 = 1;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}

	cin.ignore();
	cout << endl;
	Receipt receipt = ReceiptFactory::instance()->getReceipt(code);
	cout << receipt.toString();
	cout << endl;
	string time;
	cout << "Nhap thoi gian moi: " << endl;
	getline(cin, time);

	ReceiptFactory::instance()->setTime(receipt, time);
	system("cls");
	cout << "Don hang sau khi cap nhat :" << endl;
	cout << receipt.toString();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

void MenuEditReceipt::setModelandQuantity() {
	string code;
	system("cls");
	cout << "Nhap ma don hang cua don hang chinh sua: " << endl;
	cin >> code;
	int flag1 = 1;
	while (ReceiptFactory::instance()->findReceipt(code) == -1)
	{
		cout << "Ma don hang sai" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> code;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();
	cout << endl;
	Receipt receipt = ReceiptFactory::instance()->getReceipt(code);
	vector<pair<Motorbike, int>> items = receipt.getItems();
	cout << receipt.toString();
	cout << endl;
	cout << "STT san pham cap nhat: " << endl;
	int position;
	cin >> position;
	while (position <= 0 || position > items.size())
	{
		cout << "sai STT" << endl;
		cout << "1. Nhap lai: " << endl;
		cout << "2. Quay lai: " << endl;
		cout << "Lua chon: ";
		cin >> flag1;
		if (flag1 == 1) {
			cin >> position;
		}
		else if (flag1 == 2) return;
		else return;
	}
	cin.ignore();

	string model;
	bool existed = false;
	cout << "Nhap ten xe: " << endl;
	while (!existed)
	{
		getline(cin, model);
		while (!Motorbike::isMotorbike(model))
		{
			cout << "Ten " << model << " khong dung" << endl;
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
				getline(cin, model);
			}
			else if (flag1 == 2) return;
			else return;
		}
		vector<string>tokens = Tokenizor::split(model, " ");
		if (CompanyFactory::instance()->findModel(tokens[0], Model(tokens[1], tokens[2])) == -1)
		{
			cout << "Ten xe " << model << " khong ton tai";//write
			cout << "1. Nhap lai: " << endl;
			cout << "2. Quay lai: " << endl;
			cout << "Lua chon: ";
			cin >> flag1;
			if (flag1 == 1) {
				cin.ignore();
			}
			else if (flag1 == 2) return;
			else return;
		}
		else existed = true;
	}

	cout << "Nhap so luong san pham :" << endl;
	int n;
	cin >> n;
	while (n <= 0)
	{
		cout << "So luong san pham khong hop le" << endl;
		cout << "Nhap lai: ";
		cin >> n;
	}
	cin.ignore();
	ReceiptFactory::instance()->editItem(receipt, position - 1, model, n);

	system("cls");
	cout << "Don hang sau khi cap nhat :" << endl;
	cout << receipt.toString();
	cout << endl;

	int choose = 0;
	cout << "Tuy chon:" << endl;
	cout << "1.Quay lai menu" << endl;
	cout << "Nhap lua chon: ";
	cin >> choose;
	switch (choose) {
	case 1: {
		return;
	}
	default: {
		cout << "nhap sai lua chon" << endl;
		cout << "nhap lai lua chon: ";
		cin >> choose;
	}

	}

	system("cls");
}

